from pyMaze import maze, COLOR, agent
import numpy as np


path = 'WNENNNWWW'

m = maze(5, 5)
m.CreateMaze(theme=COLOR.light, loopPercent=10, loadMaze="maze--2023-04-06--12-13-45.csv")
a = agent(m, footprints=True)
m.tracePath({a: path})
m.run()